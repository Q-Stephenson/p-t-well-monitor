#ifndef PID_H
#define PID_H

#include <Arduino.h>
#include <PID_v1.h>

#define Kp 0.48
#define Ki 0.002
#define Kd 0.0535

#define encoderPinA 12
#define encoderPinB 13
#define PINA 0
#define PINB 1
#define PINEN 9
#define MIN_POWER 50

namespace pid{
  extern volatile long encoderPos;
  extern volatile double setpoint;
  extern volatile double input, output;

  extern PID myPID;

  void pidThread();
  void reclaimPins();
  void init();
  bool isThere();
  void goTo(long posTo);
  void step(long count);
  void loopProcess();
  void driveMotor(double power);
  void updateEncoder();
}

#endif